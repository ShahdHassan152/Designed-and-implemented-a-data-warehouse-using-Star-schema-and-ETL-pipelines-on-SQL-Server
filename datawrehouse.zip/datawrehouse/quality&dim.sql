
-----------------Create Dimension Customers
select                           
	ci.cst_id, 
	ci.cst_key, 
	ci.cst_firstname, 
	ci.cst_lastname, 
	ci.cst_marital_status, 
	ci.cst_gndr,
	ci.cst_create_date,
	ca.bdate,
	ca.gen,
	la.cntry
from silver.crm_cust_info ci 
left join silver.erp_cust_az12 ca
on ci.cst_key = ca.cid 
left join silver.erp_loc_a101 la 
on ci.cst_key = la.cid




select cst_id,count(*) from          ------------  seeing after joining the tables if ther is any duplicates
(select 
	ci.cst_id, 
	ci.cst_key, 
	ci.cst_firstname, 
	ci.cst_lastname, 
	ci.cst_marital_status, 
	ci.cst_gndr,
	ci.cst_create_date,
	ca.bdate,
	ca.gen,
	la.cntry
from silver.crm_cust_info ci 
left join silver.erp_cust_az12 ca
on ci.cst_key = ca.cid 
left join silver.erp_loc_a101 la 
on ci.cst_key = la.cid
) t group by cst_id
having count(*) > 1



select distinct                --------after joing we see that we have the column of gender is 2 columns , the cst_gender is the master so we will follow it      
	ci.cst_gndr,
	ca.gen	
from silver.crm_cust_info ci 
left join silver.erp_cust_az12 ca
on ci.cst_key = ca.cid 
left join silver.erp_loc_a101 la 
on ci.cst_key = la.cid
order by 1,2;


select distinct         ---------(data integration) new column has more info 
    ci.cst_gndr,
	ca.gen,	
	case when ci.cst_gndr != 'n/a' then ci.cst_gndr      ------crm is the master for gender info
	      else coalesce(ca.gen,'n/a')
	end as new_gen

from silver.crm_cust_info ci 
left join silver.erp_cust_az12 ca
on ci.cst_key = ca.cid 
left join silver.erp_loc_a101 la 
on ci.cst_key = la.cid
order by 1,2;

----------------------------------------------------------
-------------------------Create Dimension Products
select
    pn.prd_id,    
    pn.prd_key,   
    pn.prd_nm ,
	pn.cat_id ,
    pn.prd_cost  ,   
    pn.prd_line ,   
    pn.prd_start_dt,
	pc.cat,         
    pc.subcat,    
    pc.maintenance 

FROM silver.crm_prd_info pn
LEFT JOIN silver.erp_px_cat_g1v2 pc
          on pn.cat_id = pc.id
WHERE pn.prd_end_dt IS NULL;   --- filter out all historical data  we dont need end date bec its always null

-------------------------------------------------
----------------------- Create Fact Sales

select
    sd.sls_ord_num ,
	pr.product_key,
	cu.customer_key,
    sd.sls_order_dt,
    sd.sls_ship_dt,
    sd.sls_due_dt,
    sd.sls_sales,
    sd.sls_quantity,
    sd.sls_price 
from silver.crm_sales_details sd
LEFT JOIN gold.dim_products pr
    ON sd.sls_prd_key = pr.product_number
LEFT JOIN gold.dim_customers cu
    ON sd.sls_cust_id = cu.customer_id;




-----------------------------------------------quality checks for gold layer
------ for customers
select * from gold.dim_customers;

select distinct gender 
from gold.dim_customers;


------- for products
select prd_key, count(*) from(
select
    pn.prd_id,    
    pn.prd_key,   
    pn.prd_nm ,
	pn.cat_id ,
    pn.prd_cost  ,   
    pn.prd_line ,   
    pn.prd_start_dt,
	pc.cat,         
    pc.subcat,    
    pc.maintenance 

FROM silver.crm_prd_info pn
LEFT JOIN silver.erp_px_cat_g1v2 pc
          on pn.cat_id = pc.id
WHERE pn.prd_end_dt IS NULL
)t group by prd_key 
having count(*) >1 ;

select * from gold.dim_products;


---------------------
select * from gold.fact_sales;

--------------------------------

------ foregin key intrgrity (dimensions)
------check if all dimensions tables can join to fact table 

select *
from gold.fact_sales f
left join gold.dim_customers c 
     on c.customer_key = f.customer_key
where c.customer_key is null ; 


select *
from gold.fact_sales f
left join gold.dim_customers c 
    on c.customer_key = f.customer_key
left join gold.dim_products p 
on p.product_key = f.product_key
where p.product_key is null ; 