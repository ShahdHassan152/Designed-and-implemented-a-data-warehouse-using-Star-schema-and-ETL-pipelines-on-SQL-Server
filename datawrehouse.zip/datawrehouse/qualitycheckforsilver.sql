

select 
cst_id,
count(*)
from silver.crm_cust_info
group by cst_id
having count(*) > 1 or cst_id is null ;



------ check for unwanted spaces 

 select cst_firstname 
 from silver.crm_cust_info
 where cst_firstname != trim(cst_firstname);



 ------ data consistency & standardization 
 select distinct cst_gndr
 from silver.crm_cust_info;

  select distinct cst_marital_status
 from bronze.crm_cust_info;

select * from silver.crm_cust_info ; 



--------------------------------------------------

select 
prd_id,
count(*)
from silver.crm_prd_info
group by prd_id
having count(*) > 1 or prd_id is null ;


 select prd_nm
 from silver.crm_prd_info
 where prd_nm != trim(prd_nm);

 select * from silver.crm_prd_info ;

 ----------------------------------------
select *
from silver.crm_sales_details
where sls_order_dt > sls_ship_dt or sls_order_dt > sls_due_dt ; 


select distinct 
	sls_sales ,
	sls_quantity,
	sls_price
from silver.crm_sales_details
where sls_sales != sls_quantity *  sls_price
or sls_sales is null or sls_quantity is null or  sls_price is null 
or sls_sales <= 0  or sls_quantity <= 0  or  sls_price <= 0 
order by sls_sales,sls_quantity,sls_price;

select * from silver.crm_sales_details ;
------------------------------------------------------------------

select distinct          
bdate
FROM silver.erp_cust_az12
where bdate < '1924-01-01' or bdate > getdate();

select distinct gen 
FROM silver.erp_cust_az12;

select * from silver.erp_cust_az12;
------------------------------------------------------------------------
select distinct     
cntry
from silver.erp_loc_a101
order by cntry;

select * from silver.erp_loc_a101;

---------------------------------------------------------
select * FROM silver.erp_px_cat_g1v2;