----- do all steps in each table 
---- check for nulls or dupliates in primary key 
select
    cst_id, 
	cst_key, 
	cst_firstname, 
	cst_lastname, 
	cst_marital_status, 
	cst_gndr,
	cst_create_date
from bronze.crm_cust_info;

select 
cst_id,
count(*)
from bronze.crm_cust_info
group by cst_id
having count(*) > 1 or cst_id is null ;



------ check for unwanted spaces 

 select cst_firstname 
 from bronze.crm_cust_info
 where cst_firstname != trim(cst_firstname);



 ------ data consistency & standardization 
 select distinct cst_gndr
 from bronze.crm_cust_info;

  select distinct cst_marital_status
 from bronze.crm_cust_info;
------------------------------------------------------------------------------------
select
    prd_id,
	cat_id,
	prd_key,
	prd_nm,
	prd_cost,
	prd_line,
	prd_start_dt,
	prd_end_dt
 from bronze.crm_prd_info;

select 
prd_id,
count(*)
from bronze.crm_prd_info
group by prd_id
having count(*) > 1 or prd_id is null ;


 select prd_nm
 from bronze.crm_prd_info
 where prd_nm != trim(prd_nm);

 ---- check for nulls nrnegative nimbers
  select prd_cost
 from bronze.crm_prd_info
 where prd_cost < 0 or prd_cost is null ;

  select distinct prd_line
 from bronze.crm_prd_info;

 ---- check for invalid date orders
   select*
 from bronze.crm_prd_info
 where prd_end_dt < prd_start_dt;

 -----------------------------------------------------------------------------------------------
 select 
    sls_ord_num,
	sls_prd_key,
	sls_cust_id,
	sls_order_dt,
	sls_ship_dt,
	sls_due_dt,
	sls_sales,
	sls_quantity,
	sls_price
from bronze.crm_sales_details;

------------- issue in the date 
select 
nullif(sls_order_dt,0) sls_order_dt
from bronze.crm_sales_details
where sls_order_dt <= 0 ;


select                           ------------- has o in it we change it to null and changr type 
nullif(sls_order_dt,0) sls_order_dt
from bronze.crm_sales_details
where sls_order_dt <= 0 
or len(sls_order_dt) != 8 
or sls_order_dt > 20500101;


select                               ------ no erros in this colum only change type
nullif(sls_ship_dt,0) sls_ship_dt
from bronze.crm_sales_details
where sls_ship_dt <= 0 
or len(sls_ship_dt) != 8 
or sls_ship_dt > 20500101
or sls_ship_dt < 19000101 ;

select                               ------ no erros in this colum only change type
nullif(sls_due_dt,0) sls_due_dt
from bronze.crm_sales_details
where sls_due_dt<= 0 
or len(sls_due_dt) != 8 
or sls_due_dt > 20500101
or sls_due_dt < 19000101 ;


----- check for invalid date order  it must have the order date smaller then the ship or due 
------- lazm al order ykon abl al ship or de=ue
select * 
from bronze.crm_sales_details
where sls_order_dt > sls_ship_dt or sls_order_dt > sls_due_dt;

------ check for sales , quantity and price 
------- we have quality issues in sales and price but quantity is correct

select distinct 
	sls_sales as old_sls_sales,
	sls_quantity,
	sls_price as old_sls_price,

case when sls_sales is null or sls_sales <= 0 or sls_sales!= sls_quantity * abs(sls_price)
     then sls_quantity * abs(sls_price)
     else sls_sales 
 end as sls_sales,

 case when sls_price is null or sls_price <= 0 
         then sls_sales / nullif(sls_quantity,0)
      else sls_price
end as sls_price 

from bronze.crm_sales_details

where sls_sales != sls_quantity *  sls_price
or sls_sales is null or sls_quantity is null or  sls_price is null 
or sls_sales <= 0  or sls_quantity <= 0  or  sls_price <= 0 
order by sls_sales,sls_quantity,sls_price;

----------------------------------------------------------------------------------------------------------------
select 
	cid,
	bdate,
	gen
FROM bronze.erp_cust_az12;

select * from[silver].[crm_cust_info];

select 
	cid,
case when cid like'NAS%' then SUBSTRING(cid,4,len(cid))    ----------------- remove nas from the id 
     else cid
	 end as cid,
	bdate,
	gen
FROM bronze.erp_cust_az12
where case when cid like'NAS%' then SUBSTRING(cid,4,len(cid)) 
else cid
end not in(select distinct cst_key from silver.crm_cust_info);


select distinct           ----- ther is quality issue in date 
bdate
FROM bronze.erp_cust_az12
where bdate < '1924-01-01' or bdate > getdate();

select 	
case when cid like'NAS%' then SUBSTRING(cid,4,len(cid))   
     else cid
	 end as cid,
case when bdate > getdate() then null 
     else bdate
	 end as bdate,
	gen
FROM bronze.erp_cust_az12;

select distinct gen 
FROM bronze.erp_cust_az12;
------------------------------------------------------------------------------------------
select  ----------------- in this table the cid has dash in it w have to remove this to match the other ids 
cid,
cntry
from bronze.erp_loc_a101;

select cst_key from silver.crm_cust_info;


select
replace (cid,'-','') cid,
cntry
from bronze.erp_loc_a101
where replace (cid,'-','')  not in 
(select cst_key from silver.crm_cust_info);

select distinct       --------------errors in the country
cntry
from bronze.erp_loc_a101
order by cntry;

select distinct 
cntry as old_cntry,
	CASE
		WHEN TRIM(cntry) = 'DE' THEN 'Germany'
		WHEN TRIM(cntry) IN ('US', 'USA') THEN 'United States'
		WHEN TRIM(cntry) = '' OR cntry IS NULL THEN 'n/a'
		ELSE TRIM(cntry)
	END AS cntry 
from bronze.erp_loc_a101
order by cntry;
-----------------------------------------------------------------------------------
------------------- no errors in this table 
SELECT
	id,
	cat,
	subcat,
	maintenance
FROM bronze.erp_px_cat_g1v2;

------ check unwanted spaces 
select * from bronze.erp_px_cat_g1v2
where cat != trim(cat) or subcat != trim(subcat) or  maintenance != trim(maintenance) ;

------- data standardization & consistency 
select distinct
cat 
from bronze.erp_px_cat_g1v2;

select distinct
subcat 
from bronze.erp_px_cat_g1v2;

select distinct
maintenance 
from bronze.erp_px_cat_g1v2;


-------------------------------------------------------------


