EXEC bronze.load_bronze


EXEC silver.load_silver